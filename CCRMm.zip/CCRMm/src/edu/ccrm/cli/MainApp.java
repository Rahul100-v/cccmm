package edu.ccrm.cli;

import edu.ccrm.domain.*;
import edu.ccrm.service.*;
import java.util.*;

public class MainApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentService studentService = new StudentService();
        CourseService courseService = new CourseService();
        EnrollmentService enrollmentService = new EnrollmentService();

        int choice;
        do {
            System.out.println("\n==== Campus Course & Records Manager ====");
            System.out.println("1. Add Student");
            System.out.println("2. List Students");
            System.out.println("3. Add Course");
            System.out.println("4. List Courses");
            System.out.println("5. Enroll Student in Course");
            System.out.println("6. Unenroll Student from Course");
            System.out.println("7. List Enrollments");
            System.out.println("8. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt(); sc.nextLine();

            switch(choice) {
                case 1:
                    System.out.print("Enter ID: "); int id = sc.nextInt(); sc.nextLine();
                    System.out.print("Enter RegNo: "); String reg = sc.nextLine();
                    System.out.print("Enter Name: "); String name = sc.nextLine();
                    System.out.print("Enter Email: "); String email = sc.nextLine();
                    studentService.addStudent(new Student(id, reg, name, email));
                    break;
                case 2:
                    studentService.listStudents();
                    break;
                case 3:
                    System.out.print("Enter Code: "); String code = sc.nextLine();
                    System.out.print("Enter Title: "); String title = sc.nextLine();
                    System.out.print("Enter Credits: "); int credits = sc.nextInt(); sc.nextLine();
                    System.out.print("Enter Instructor: "); String instr = sc.nextLine();
                    System.out.print("Enter Dept: "); String dept = sc.nextLine();
                    System.out.print("Enter Semester (SPRING/SUMMER/FALL): ");
                    Semester sem = Semester.valueOf(sc.nextLine().toUpperCase());
                    courseService.addCourse(new Course(code, title, credits, instr, dept, sem));
                    break;
                case 4:
                    courseService.listCourses();
                    break;
                case 5:
                    System.out.print("Enter Student RegNo: "); String sReg = sc.nextLine();
                    System.out.print("Enter Course Code: "); String cCode = sc.nextLine();
                    Student student = studentService.findByRegNo(sReg);
                    Course course = courseService.findByCode(cCode);
                    if (student != null && course != null) enrollmentService.enroll(student, course);
                    else System.out.println("Invalid Student or Course!");
                    break;
                case 6:
                    System.out.print("Enter Student RegNo: "); sReg = sc.nextLine();
                    System.out.print("Enter Course Code: "); cCode = sc.nextLine();
                    student = studentService.findByRegNo(sReg);
                    course = courseService.findByCode(cCode);
                    if (student != null && course != null) enrollmentService.unenroll(student, course);
                    else System.out.println("Invalid Student or Course!");
                    break;
                case 7:
                    enrollmentService.listEnrollments();
                    break;
                case 8:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while(choice != 8);
        sc.close();
    }
}
