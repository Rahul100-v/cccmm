package edu.ccrm.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Student {
    private int id;
    private String regNo;
    private String fullName;
    private String email;
    private boolean active;
    private LocalDate createdDate;
    private List<Course> enrolledCourses;

    public Student(int id, String regNo, String fullName, String email) {
        this.id = id;
        this.regNo = regNo;
        this.fullName = fullName;
        this.email = email;
        this.active = true;
        this.createdDate = LocalDate.now();
        this.enrolledCourses = new ArrayList<>();
    }

    public void enroll(Course course) { enrolledCourses.add(course); }
    public void unenroll(Course course) { enrolledCourses.remove(course); }

    public String getRegNo() { return regNo; }
    public String getFullName() { return fullName; }

    @Override
    public String toString() {
        return id + " | " + regNo + " | " + fullName + " | " + email + " | " + (active ? "Active" : "Inactive");
    }
}
