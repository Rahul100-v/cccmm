package edu.ccrm.domain;

public class Course {
    private String code;
    private String title;
    private int credits;
    private String instructor;
    private String department;
    private Semester semester;

    public Course(String code, String title, int credits, String instructor, String dept, Semester semester) {
        this.code = code;
        this.title = title;
        this.credits = credits;
        this.instructor = instructor;
        this.department = dept;
        this.semester = semester;
    }

    public String getCode() { return code; }
    public String getTitle() { return title; }

    @Override
    public String toString() {
        return code + " | " + title + " | " + credits + "cr | " + instructor + " | " + department + " | " + semester;
    }
}
