package edu.ccrm.domain;

public class Enrollment {
    private Student student;
    private Course course;

    public Enrollment(Student student, Course course) {
        this.student = student;
        this.course = course;
    }

    public Student getStudent() { return student; }
    public Course getCourse() { return course; }

    @Override
    public String toString() {
        return student.getRegNo() + " -> " + course.getCode() + " (" + course.getTitle() + ")";
    }
}
