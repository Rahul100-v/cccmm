package edu.ccrm.service;

import edu.ccrm.domain.Student;
import java.util.*;

public class StudentService {
    private List<Student> students = new ArrayList<>();

    public void addStudent(Student s) {
        students.add(s);
        System.out.println("Student added successfully!");
    }

    public void listStudents() {
        if (students.isEmpty()) System.out.println("No students found.");
        else for (Student s : students) System.out.println(s);
    }

    public Student findByRegNo(String regNo) {
        for (Student s : students) {
            if (s.getRegNo().equalsIgnoreCase(regNo)) return s;
        }
        return null;
    }
}
