package edu.ccrm.service;

import edu.ccrm.domain.*;
import java.util.*;

public class EnrollmentService {
    private List<Enrollment> enrollments = new ArrayList<>();

    public void enroll(Student s, Course c) {
        enrollments.add(new Enrollment(s, c));
        s.enroll(c);
        System.out.println("Enrolled " + s.getFullName() + " in " + c.getTitle());
    }

    public void unenroll(Student s, Course c) {
        enrollments.removeIf(e -> e.getStudent().equals(s) && e.getCourse().equals(c));
        s.unenroll(c);
        System.out.println("Unenrolled " + s.getFullName() + " from " + c.getTitle());
    }

    public void listEnrollments() {
        if (enrollments.isEmpty()) System.out.println("No enrollments found.");
        else for (Enrollment e : enrollments) System.out.println(e);
    }
}
