package edu.ccrm.service;

import edu.ccrm.domain.Course;
import java.util.*;

public class CourseService {
    private List<Course> courses = new ArrayList<>();

    public void addCourse(Course c) {
        courses.add(c);
        System.out.println("Course added successfully!");
    }

    public void listCourses() {
        if (courses.isEmpty()) System.out.println("No courses found.");
        else for (Course c : courses) System.out.println(c);
    }

    public Course findByCode(String code) {
        for (Course c : courses) {
            if (c.getCode().equalsIgnoreCase(code)) return c;
        }
        return null;
    }
}
